package library;

public class invalidUser extends Exception {
    public invalidUser(String message) {
        super(message);
    }    
}
